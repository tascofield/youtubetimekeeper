# youtubetimekeeper
 
A firefox extension that constantly updates youtube urls to include the current time